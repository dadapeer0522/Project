﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


namespace Aadhaarapp
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=cohort2;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                HttpCookie cookie = Request.Cookies["AadhaarNumber"];
                if (txtAadhaar2.Text == cookie["Aadhaar"])
                {
                    string num = "0123456789";
                    int len = num.Length;
                    string otp = string.Empty;
                    int otpdigit = 4;
                    string finaldigit;
                    int getindex;
                    for (int i = 0; i < otpdigit; i++)
                    {
                        do
                        {
                            getindex = new Random().Next(0, len);
                            finaldigit = num.ToCharArray()[getindex].ToString();
                        } while (otp.IndexOf(finaldigit) != -1);
                        otp += finaldigit;
                    }
                    lotp.Text = otp;


                    HttpCookie cookiee = new HttpCookie("UserInfo");
                    cookiee["Aadhaar1"] = txtAadhaar2.Text;
                    cookiee["Secret pin"] = txtpin.Text;
                    cookiee["otp pin"] = lotp.Text;
                    cookiee.Expires = DateTime.Now.AddDays(30);
                    Response.Cookies.Add(cookiee);
                    Response.Redirect("~/WebformDashboard.aspx");
                    //Response.Redirect("~/WebformDashboard.aspx");
                    //Response.Write("<script>alert('Correct')</script>");
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "insert into table_name values('" + txtAadhaar2.Text + "', '" + txtpin.Text + "', '"+lotp.Text+"')";
                    cmd.ExecuteNonQuery();
                    con.Close();
                    

                }
                else
                {
                    Response.Write("<script>alert('Enter Correct Aadhaar Number')</script>");
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}