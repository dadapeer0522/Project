﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace Aadhaarapp
{
    public partial class Voting : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=cohort2;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void B1(object sender, EventArgs e)
        {
            try
            {
                HttpCookie cookiee = Request.Cookies["UserInfo"];
                if (cookiee != null)
                {
                    if (txtAadhaar3.Text == cookiee["Aadhaar1"] && txtpin1.Text == cookiee["Secret pin"] && txtpin2.Text == cookiee["otp pin"])
                    {
                        Response.Redirect("~/Parties.aspx");
                    }
                }
                else
                {
                    Response.Write("<script>alert('Please Generate Secret Pin ')</script>");
                }
                Response.Redirect("~/Parties.aspx");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}