﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace Aadhaarapp
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login_Click(object sender, EventArgs e)
        {
            string constr = WebConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select COUNT(*) from Aadhaar_ where UD = '" + txtAadhaar1.Text + "' and PW = '" + txtPassword.Text + "'", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                cmd.ExecuteNonQuery();
                con.Close();
                if (dt.Rows[0][0].ToString()== "1")
                {
                    //Response.Write("<script>alert('Login Successful')</script>");
                    string num = "0123456789";
                    int len = num.Length;
                    string otp = string.Empty;
                    int otpdigit = 5;
                    string finaldigit;
                    int getindex;
                    for(int i=0;i< otpdigit;i++)
                    {
                        do
                        {
                            getindex = new Random().Next(0, len);
                            finaldigit = num.ToCharArray()[getindex].ToString();
                        } while (otp.IndexOf(finaldigit) != -1);
                        otp += finaldigit;
                    }
                    OTP.Text = otp;
                }
                else
                {
                    Response.Write("<script>alert('Error in Login')</script>");
                }
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
        

        protected void Submit_Click(object sender, EventArgs e)
        {
            try
            {
                if (OTP.Text == txtotp.Text)
                {
                    //Transfer aadhaar number to webform2 to verify
                    HttpCookie cookie = new HttpCookie("AadhaarNumber");
                    cookie["Aadhaar"] = txtAadhaar1.Text;
                    cookie.Expires = DateTime.Now.AddDays(30);
                    Response.Cookies.Add(cookie);

                    Response.Redirect("~/WebformDashboard.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Enter Correct OTP')</script>");
                }
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);
            }

        }
    }
}